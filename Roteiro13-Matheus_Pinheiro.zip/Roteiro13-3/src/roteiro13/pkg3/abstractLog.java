/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13.pkg3;

/**
 *
 * @author matheus
 */
public abstract class abstractLog {
   
    public static int INFO=1;
    public static int DEBUG=2;
    public static int ERROR=3;
    protected int level;
    protected abstractLog nexLog;

    public void setNexLog(abstractLog nexLog) {
        this.nexLog = nexLog;
    }
    
    public void logMessage(int x,String a){
        switch(x){
            case 1 :
                System.out.println("Console: "+a);
                break;
            case 2:
                System.out.println("File: "+a);
                break;
            case 3:
                System.out.println("Error: "+a);
                    break;
        }
        
    }
    protected abstract void write(String a);
    
}
