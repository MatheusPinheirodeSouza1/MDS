/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13.pkg3;

/**
 *
 * @author matheus
 */
public class GofChainOfResponsability {

    public static void main(String[] args) {
        abstractLog  a = getChainOfLog();
    }

    private static abstractLog getChainOfLog() {
        int x=1;
        abstractLog al1 = new ErrorLog(x);
        al1.setNexLog(new FileLog(x));
        al1.setNexLog(new Consolelog(x));
        x=2;
        System.out.println("-----------------");
        abstractLog al2 = new ErrorLog(x);
        al2.setNexLog(new FileLog(x));
        al2.setNexLog(new Consolelog(x));
        x=3;
         System.out.println("-----------------");
        abstractLog al3 = new ErrorLog(x);
        al3.setNexLog(new FileLog(x));
        al3.setNexLog(new Consolelog(x));
         System.out.println("-----------------");
        return al1;
    }
}
