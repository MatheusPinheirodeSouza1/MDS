/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13.pkg3;

/**
 *
 * @author matheus
 */
public class ErrorLog extends abstractLog{

    public ErrorLog(int x) {
        if(3!=x)
         System.out.println("Nivel chamado 3 Nivel executar:"+x );
        else
            write("Enviando um erro");
    }
    
    
    protected void write(String a){
         level=1;
        logMessage(3, a);
    }
}
