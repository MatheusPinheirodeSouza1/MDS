/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13.pkg3;

/**
 *
 * @author matheus
 */
public class Consolelog extends abstractLog{

    public Consolelog(int x) {
        if(1!=x)
        System.out.println("Nivel chamado 1 Nivel executar:"+x );
        else
            write("Enviando uma menssage");
    }
    
    protected void write(String a){
        level=1;
        logMessage(1, a);
    }
    
}
