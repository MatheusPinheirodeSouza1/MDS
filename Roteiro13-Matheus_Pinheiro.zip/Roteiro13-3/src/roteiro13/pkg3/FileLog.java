/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13.pkg3;

/**
 *
 * @author matheus
 */
public class FileLog extends abstractLog{

    public FileLog(int x) {
        if(2!=x)
         System.out.println("Nivel chamado 2 Nivel executar:"+x );
        else
            write("Enviando informação de debug");
    }
    
    protected void write(String a){
        level=1;
        logMessage(2, a);
    }
}
