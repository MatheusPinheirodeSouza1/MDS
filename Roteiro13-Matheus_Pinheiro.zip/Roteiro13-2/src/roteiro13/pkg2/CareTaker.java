/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13.pkg2;

import java.util.ArrayList;


public class CareTaker {
    private ArrayList<Memento> mementoList = new ArrayList<>();
    
    public void add(Memento m){
        mementoList.add(m);
    }
    
    public Memento get(int i){
      return  mementoList.get(i);
    }
        
}
