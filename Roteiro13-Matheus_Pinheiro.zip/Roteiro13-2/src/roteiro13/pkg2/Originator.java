/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13.pkg2;

/**
 *
 * @author matheus
 */
public class Originator {
    private float valor;

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }
    
    public Memento saveValorToMemento(){
        Memento m = new Memento(valor);
        return m;
    }
    public void getValorToMemento(Memento m){
        this.valor=m.getValor();
    }
}
