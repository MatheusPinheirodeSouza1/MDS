/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13.pkg2;

/**
 *
 * @author matheus
 */
public class TesteMemento {
    
        public static void main(String[] args) {
            float valor=400;
            Originator o;
            System.out.println("Valor corrente: "+valor);
            CareTaker ct = new CareTaker();
            int i=-1;// -1 pois seria um valor nulo de i, como 0 é um valor valido não se pode inicializar i com 0
            for(;valor>0;valor=valor-100){
                o = new Originator();
                o.setValor(valor);
                ct.add(o.saveValorToMemento());
                i++;
            }
            for(;i>=0;i--)
                System.out.println(i+"-Valor salvo: "+ct.get(i).getValor());
        }
}
