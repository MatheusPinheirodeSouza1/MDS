/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13.pkg4;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author matheus
 */
public class Subject {

    private List<Observer> lo = new ArrayList<Observer>();
    private int state;

    public Subject(int state) {
        this.state = state;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
        notifyAllObservers();
    }

    public void attach(Observer o) {
        lo.add(o);
    }

    public void notifyAllObservers() {
        for (Observer observer : lo) {
            observer.update();
        }
    }
}
