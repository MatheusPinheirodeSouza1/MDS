/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13.pkg4;

public class GofObserver {
    public static void main(String[] args) {
        Subject s = new Subject(10);
        s.attach(new BinaryObserver(s));
        s.attach(new HexaObserver(s));
        s.attach(new OctalObserver(s));
        System.out.println("Primeiro valor= 15");
        s.setState(10);
        System.out.println("Segundo valor= 20");
        s.setState(20);
    }
}
