/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13;

/**
 *
 * @author matheus
 */
public class main {

    public static void main(String[] args) {

        Ponto p1 =new Ponto(9,0);
        Ponto p2 = new Ponto(11,0);
        Figura roda1 = new Circulo(p1, p2);
        roda1.setCor("preto");
        Ponto p3 =new Ponto(29,0);
        Ponto p4 = new Ponto(31,0);
        Figura roda2 = new Circulo(p3, p4);
        roda2.setCor("preto");
        Ponto p5 =new Ponto(0,5);
        Ponto p6 = new Ponto(0,25);
        Ponto p7 =new Ponto(40,5);
        Ponto p8 = new Ponto(40,25);
        Figura baixo = new Quadrilatero(p5, p6, p7, p8);
        baixo.setCor("preto");
        Ponto p9 =new Ponto(10,10);
        Ponto p10 = new Ponto(10,30);
        Ponto p11 =new Ponto(30,10);
        Ponto p12 = new Ponto(30,30);
        Figura cima = new Quadrilatero(p9, p10, p11, p12);
        cima.setCor("branco");
        GerarCarrinho gc = new GerarCarrinho("preto");
        gc.setRoda1(roda1);
        gc.setRoda2(roda2);
        gc.setCima(cima);
        gc.setBaixo(baixo);
        gc.desenha();
        
    }

}
