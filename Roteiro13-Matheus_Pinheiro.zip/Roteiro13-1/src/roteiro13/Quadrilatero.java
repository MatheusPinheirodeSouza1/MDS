/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13;

/**
 *
 * @author matheus
 */
public class Quadrilatero extends Figura{
    private Ponto p1;
    private Ponto p2;
    private Ponto p3;
    private Ponto p4;

    public Quadrilatero(Ponto p1, Ponto p2, Ponto p3, Ponto p4) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.p4 = p4;
    }

    @Override
    public void desenha() {
        super.desenha();
        if((p3.getX()-p1.getX())==(p4.getX()-p2.getX()) && (p3.getX()-p1.getX())==(p2.getY()-p1.getY()) && (p2.getY()-p1.getY())==(p4.getY()-p3.getY()))            
            System.out.println("Desenhando um quadrado "+ cor);
        else
            System.out.println("Desenhando um retangulo "+ cor);
    }
    
    
}
