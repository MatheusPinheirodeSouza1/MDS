/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13;

/**
 *
 * @author matheus
 */
public class GerarCarrinho implements Forma{
    
    private Figura roda1 = new Figura();
    private Figura roda2 = new Figura();
    private Figura baixo = new Figura();
    private Figura cima = new Figura();
    
    public GerarCarrinho(String cor){
        roda1.setCor(cor);
        roda2.setCor(cor);
        baixo.setCor(cor);
        cima.setCor(cor);
        desenha();
    }
    public void desenha() {
        roda1.desenha();
        roda2.desenha();
        baixo.desenha();
        cima.desenha();
    }

    public Figura getRoda1() {
        return roda1;
    }

    public void setRoda1(Figura roda1) {
        this.roda1 = roda1;
    }

    public Figura getRoda2() {
        return roda2;
    }

    public void setRoda2(Figura roda2) {
        this.roda2 = roda2;
    }

    public Figura getBaixo() {
        return baixo;
    }

    public void setBaixo(Figura baixo) {
        this.baixo = baixo;
    }

    public Figura getCima() {
        return cima;
    }

    public void setCima(Figura cima) {
        this.cima = cima;
    }
    
}
