/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro13;

/**
 *
 * @author matheus
 */
public class Circulo extends Figura {
    private Ponto p1;
    private Ponto p2;

    public Circulo(Ponto p1, Ponto p2) {
        this.p1 = p1;
        this.p2 = p2;
    }

    @Override
    public void desenha() {
        super.desenha(); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Desenhando um circulo "+ cor);
    }
    
    
}
